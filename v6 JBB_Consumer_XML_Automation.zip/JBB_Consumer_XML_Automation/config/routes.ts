import { env } from './env';

const buildListUrl = (objectName: string, query?: string) => {
  const baseUrl = `${env.baseUrl}/lightning/o/${objectName}/list`;
  return query ? `${baseUrl}?${query}` : baseUrl;
};

export const routes = {
  base: env.baseUrl,
  accounts: buildListUrl('Account'),
  accountList: (query?: string) => buildListUrl('Account', query),
  accountView: (accountId: string) =>
    `${env.baseUrl}/lightning/r/Account/${accountId}/view`,

  contacts: buildListUrl('Contact'),
  contactList: (query?: string) => buildListUrl('Contact', query),

  opportunities: buildListUrl('Opportunity'),
  opportunityList: (query?: string) => buildListUrl('Opportunity', query),
  opportunityView: (opportunityId: string) =>
    `${env.baseUrl}/lightning/r/Opportunity/${opportunityId}/view`,

  consumerReports: buildListUrl('forseva1__EquifaxConsumer__c'),

  consumerReportList: (query?: string) =>
    buildListUrl('forseva1__EquifaxConsumer__c', query),

  consumerReportView: (reportId: string) =>
    `${env.baseUrl}/lightning/r/forseva1__EquifaxConsumer__c/${reportId}/view`,
};
