import dotenv from 'dotenv';

dotenv.config();

export const env = {
    loginMode: process.env.LOGIN_MODE || 'LMA',

    
    // Direct Salesforce login
    sfBaseUrl: process.env.SF_BASE_URL,
    sfUsername: process.env.SF_USERNAME,
    sfPassword: process.env.SF_PASSWORD,

    // LMA login
    baseUrl: process.env.LMA_URL,
    username: process.env.LMA_USERNAME,
    password: process.env.LMA_PASSWORD,

    // Subscriber configuration
    subscriberOrgId: process.env.SUBSCRIBER_ORG_ID,
    subscriberOrgName: process.env.SUBSCRIBER_ORG_NAME,

    // Consumer XML configuration
    listViewName: process.env.LIST_VIEW_NAME,
    monthRange: Number(process.env.MONTH_RANGE || 3),
    startDate: process.env.START_DATE,
    endDate: process.env.END_DATE,

    //Download Path
    downloadPath: process.env.DOWNLOAD_PATH,
};
if (env.loginMode.toUpperCase() === 'LMA') {
    if (!env.baseUrl) {
        throw new Error('LMA_URL is missing in .env');
    }

    if (!env.username) {
        throw new Error('LMA_USERNAME is missing in .env');
    }

    if (!env.password) {
        throw new Error('LMA_PASSWORD is missing in .env');
    }

    if (!env.subscriberOrgId) {
        throw new Error('SUBSCRIBER_ORG_ID is missing in .env');
    }

    if (!env.subscriberOrgName) {
        throw new Error('SUBSCRIBER_ORG_NAME is missing in .env');
    }
}

if (env.loginMode.toUpperCase() === 'DIRECT') {
    if (!env.sfBaseUrl) {
        throw new Error('SF_BASE_URL is missing in .env');
    }

    if (!env.sfUsername) {
        throw new Error('SF_USERNAME is missing in .env');
    }

    if (!env.sfPassword) {
        throw new Error('SF_PASSWORD is missing in .env');
    }
}

if (!env.listViewName) {
    throw new Error('LIST_VIEW_NAME is missing in .env');
}

if (
    !Number.isFinite(env.monthRange) ||
    env.monthRange <= 0
) {
    throw new Error(
        'MONTH_RANGE must be a number greater than 0 in .env'
    );
}