/**
 * Consumer XML Download Automation
 *
 * Purpose:
 * - Logs in through LMA or direct Salesforce login.
 * - Opens the configured Equifax Consumer Reports list view.
 * - Collects reports within the configured month range.
 * - Downloads available XML files.
 * - Captures screenshots when XML is unavailable.
 * - Saves progress so interrupted runs can resume.
 *
 * Client configuration is maintained in the .env file:
 * - LOGIN_MODE
 * - LMA / direct Salesforce credentials
 * - SUBSCRIBER_ORG_ID
 * - SUBSCRIBER_ORG_NAME
 * - LIST_VIEW_NAME
 * - MONTH_RANGE
 * - DOWNLOAD_PATH
 *
 * Important:
 * Do not keep Current_Run or files inside it open when the script
 * is completing. Windows may prevent the folder from being renamed.
 */
import { Page, expect } from '@playwright/test';

export class LoginPage {
  constructor(private page: Page) {}

  private usernameTxt = '#username';
  private passwordTxt = '#password';
  private loginBtn = '#Login';

  async navigate(url: string) {
    await this.page.goto(url, {
      waitUntil: 'networkidle'
    });
  }

  async login(username: string, password: string) {
    await this.page.fill(this.usernameTxt, username);
    await this.page.fill(this.passwordTxt, password);
    await this.page.click(this.loginBtn);
  }

  async verifyLoginSuccessful() {
    await expect(this.page).not.toHaveURL(/login/i);
  }
}
