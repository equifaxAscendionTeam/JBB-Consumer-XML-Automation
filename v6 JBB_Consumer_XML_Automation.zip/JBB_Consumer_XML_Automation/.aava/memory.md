# Aava Memory Index

This file contains pointers to detailed topic-specific memory files in the project.

## 1. Project Memory (.aava/memory/)
- No detailed project memory topics recorded yet.

## 2. Local Memory (.aava/memory-local/)
- No local topics recorded yet.

## 3. User Global Memory (~/.aava/agent-memory/)
- No global user topics recorded yet.

## .aava/AGENTS.md#STYLE
- **Playwright Reporter Path Resolution**: Always use `config.configFile` or `config.rootDir` in `onBegin()` to resolve output directories, not `process.cwd()`, to handle cases where tests run from subdirectories (e.g., via `uv` or monorepo setups).
