# Discovered Skills Registry

*Generated at: 10/15/2026, 3:01:58 PM*

This document is a categorical index of all skills discovered across the workspace and system.

## Advanced Development
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$brainstorming_advance` | You MUST use this before any creative work - creating features, building components, adding functionality, or modifying behavior. Explores user intent, requirements and design before implementation. | `plugin` | - |
| `$systematic-debugging_advance` | Use when encountering any bug, test failure, or unexpected behavior, before proposing fixes | `plugin` | - |
| `$test-driven-development_advance` | Use when implementing any feature or bugfix, before writing implementation code | `plugin` | - |
| `$using-superpowers_advance` | Use when starting any conversation - establishes how to find and use skills, requiring Skill tool invocation before ANY response including clarifying questions | `plugin` | - |
| `$verification-before-completion_advance` | Use when about to claim work is complete, fixed, or passing, before committing or creating PRs - requires running verification commands and confirming output before making any success claims; evidence before assertions always | `plugin` | - |

## Advanced Workflows
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$dispatching-parallel-agents_advance` | Use when facing 2+ independent tasks that can be worked on without shared state or sequential dependencies | `plugin` | - |
| `$executing-plans_advance` | Use when you have a written implementation plan to execute in a separate session with review checkpoints | `plugin` | - |
| `$finishing-a-development-branch_advance` | Use when implementation is complete, all tests pass, and you need to decide how to integrate the work - guides completion of development work by presenting structured options for merge, PR, or cleanup | `plugin` | - |
| `$receiving-code-review_advance` | Use when receiving code review feedback, before implementing suggestions, especially if feedback seems unclear or technically questionable - requires technical rigor and verification, not performative agreement or blind implementation | `plugin` | - |
| `$subagent-driven-development_advance` | Use when executing implementation plans with independent tasks in the current session | `plugin` | - |
| `$writing-plans_advance` | Use when you have a spec or requirements for a multi-step task, before touching code | `plugin` | - |

## Analytics & Costs
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$stats` | Expert agent that provides deep project analytics, commit frequency, and identifies bug-prone hotspots. | `builtin` | - |

## Architectural Project
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$advisor` | Expert agent that provides architectural design critiques, pattern suggestions, and code reviews. | `builtin` | - |
| `$branch` | Expert agent that manages parallel implementation forks and reasoning paths. | `builtin` | - |
| `$bridge` | Expert agent that designs and audits structural connections between systems, layers, and databases. | `builtin` | - |

## Build & Implementation
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$context-eng` | Optimizes agent context setup by feeding the right information at the right time for maximum output quality | `plugin` | - |
| `$incremental-impl` | Delivers changes in thin vertical slices, implementing one piece, testing it, verifying it, then expanding | `plugin` | `$task-breakdown` |
| `$prompt-eng` | Guides effective prompt engineering for AI-powered features including system prompts, structured outputs, evaluation, and anti-patterns | `plugin` | - |
| `$source-driven-dev` | Grounds every implementation decision in official documentation to ensure authoritative, source-cited code | `plugin` | - |
| `$tdd-practice` | Drives development with tests - write a failing test before writing the code that makes it pass | `plugin` | - |

## Context & Memory
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$compact` | Expert agent that triggers manual context compaction for session stability and token efficiency. | `builtin` | - |
| `$context` | Expert agent that visualizes and audits the current context window usage and token consumption. | `builtin` | - |
| `$remember` | Expert agent that reviews, summarizes, and reconstructs previous mission context and session engineering decisions. | `builtin` | - |

## Define & Ideation
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$spec-driven-dev` | Creates structured specifications before coding to define what we're building, why, and how we'll know it's done | `plugin` | `$idea-refine` |

## Design & UI
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$init-design` | Bootstrap a DESIGN.md for this project. Scans the codebase for design signals, asks only what it cannot detect, then writes a world-class DESIGN.md following the canonical 9-section format. | `builtin` | - |
| `$theme` | Expert agent that audits the project's color palette, accessibility, and theme token consistency. | `builtin` | - |

## Development & Git
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$diff` | Expert agent that analyzes the current git diff and explains the functional impact and side effects. | `builtin` | - |

## Development Workflows
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$plan-executor` | Executes implementation plans with atomic commits, deviation handling, checkpoint protocols, and state management | `plugin` | - |

## Diagnostic & Debug
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$debug` | Expert agent that enables debug logging and diagnoses issues in the current Aava session by reading logs. | `builtin` | - |
| `$doctor` | Expert agent that diagnoses environment issues, missing dependencies, and project health. | `builtin` | - |
| `$verify` | Expert agent that performs a meticulous audit of the current implementation against the original task goals and success criteria. | `builtin` | - |

## Environments & Config
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$config` | Expert agent that displays and audits Aava's operational configuration and system parameters. | `builtin` | - |

## History & Intent
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$rewind` | Expert agent that investigates git history and session logs to reconstruct the reasoning behind past changes. | `builtin` | - |

## Information
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$skills` | Generate and view the multi-dimensional registry of all discovered specialist skills. | `builtin` | - |

## Information & Context
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$brief` | Expert agent that provides a rapid 1-page "Cheat Sheet" for the current repository. | `builtin` | - |
| `$insights` | Expert agent that performs a deep repository-wide analysis of patterns, frictions, and architectural health. | `builtin` | - |
| `$status` | Expert agent that provides a dense, actionable summary of the current project state, branch, and activity. | `builtin` | - |
| `$summary` | Expert agent that generates a high-fidelity summary of long sessions for hand-offs or long-term record keeping. | `builtin` | - |

## Optimization
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$perf` | Expert agent that identifies and resolves performance bottlenecks. | `builtin` | - |
| `$simplify` | Clean up the current code changes for better reuse, quality, and performance. | `builtin` | - |
| `$skillify` | Expert agent that captures this session's repeatable process as a reusable Aava skill. | `builtin` | - |

## Orchestration & Logic
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$effort` | Expert agent that modulates the intensity of reasoning and verification (low, medium, high, max). | `builtin` | - |
| `$fast` | Expert agent that focuses on rapid, high-confidence implementation for trivial tasks. | `builtin` | - |

## Planning & Scoping
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$lifecycle-guide` | Discovers and invokes the right development lifecycle skill for the current task across Define, Plan, Build, Verify, Review, and Ship phases | `plugin` | - |
| `$task-breakdown` | Decomposes work into small, verifiable tasks with explicit acceptance criteria and dependency ordering | `plugin` | `$spec-driven-dev` |

## Production & Shipping
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$commit` | Generates a high-quality conventional commit message for staged changes. | `builtin` | - |
| `$issue` | Expert agent that drafts high-fidelity bug reports or feature specifications based on the session. | `builtin` | - |
| `$pr` | Expert agent that drafts professional PR comments and architectural reviews of the current diff. | `builtin` | - |
| `$review` | Expert agent for thorough PR/branch code reviews (logic, edge cases, and quality). | `builtin` | - |
| `$ship` | Expert agent that automates the release lifecycle: commits, pushes, and generates high-quality PR drafts. | `builtin` | - |

## Reflection & Debug
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$thinkback` | Expert agent that self-audits the current session for logical errors or misinterpreted requirements. | `builtin` | - |

## Review & Quality
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$code-review-with-verify` | Reviews code then verifies all critical findings are addressed before closing. | `plugin` | `$code-simplify` |
| `$code-simplify` | Simplifies code by reducing complexity while preserving exact behavior for better readability and maintainability | `plugin` | `$quality-review` |
| `$perf-optimize` | Optimizes application performance with a measure-first approach targeting Core Web Vitals and backend response times | `plugin` | - |
| `$quality-review` | Conducts multi-axis code review across correctness, readability, architecture, security, and performance dimensions | `plugin` | - |
| `$refactor` | Guides safe code refactoring that restructures without changing behavior using systematic techniques and continuous test verification | `plugin` | `$quality-review` |
| `$security-hardening` | Hardens code against vulnerabilities with security-first development practices for web applications | `plugin` | - |
| `$senior-reviewer` | Senior code reviewer that evaluates changes across five dimensions - correctness, readability, architecture, security, and performance | `plugin` | - |

## Security & Audit
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$security` | Scans the codebase or a specific diff for common security vulnerabilities (OWASP, etc.). | `builtin` | - |

## Ship & Deliver
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$git-workflow` | Structures git workflow practices with trunk-based development, atomic commits, and disciplined version control | `plugin` | - |

## Utilities
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$clear` | Expert utility to wipe the current conversation context and start a fresh session. | `builtin` | - |
| `$copy` | Expert agent that formats and copies session artifacts (plans, tasks, code) to the system clipboard. | `builtin` | - |
| `$help` | Show the interactive command manual and browse all available agentic capabilities. | `builtin` | - |
| `$reset` | Expert agent that clears session history, state, and planning files to start a fresh mission. | `builtin` | - |

## Verify & Testing
| Skill | Description | Source | Composes |
| :--- | :--- | :--- | :--- |
| `$error-recovery` | Guides systematic root-cause debugging when tests fail, builds break, or behavior doesn't match expectations | `plugin` | - |


---
## Tips
- Use `$` in the chat to trigger these skills.
- Each skill provides specialized agentic reasoning for its domain.
