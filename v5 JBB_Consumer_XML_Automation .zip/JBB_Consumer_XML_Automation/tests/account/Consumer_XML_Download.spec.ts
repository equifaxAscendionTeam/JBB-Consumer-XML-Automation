import {
    test,
    expect,
    Page,
    Locator,
} from '@playwright/test';

import fs from 'fs';
import path from 'path';
import os from 'os';


import { env } from '../../config/env';

const isVisible = (locator: Locator) =>
    locator.isVisible().catch(() => false);
/**
 * Waits for the first successful browser outcome.
 *
 * Salesforce subscriber login may either:
 * - open a new browser tab, or
 * - reuse the current tab.
 */

function waitForOutcome<K extends string>(
    conditions: Record<K, () => Promise<unknown>>
): Promise<K | null> {
    const entries = Object.entries(conditions) as [
        K,
        () => Promise<unknown>
    ][];

    return new Promise((resolve) => {
        let pending = entries.length;

        for (const [key, run] of entries) {
            run()
                .then(() => resolve(key))
                .catch(() => {
                    if (--pending === 0) {
                        resolve(null);
                    }
                });
        }
    });
}
/* ------------------------------------------------------------------ */
/* Salesforce Login and Subscriber Org Navigation                      */
/* ------------------------------------------------------------------ */

async function isSubscriberAccountPage(page: Page): Promise<boolean> {
    return /\/lightning\/(r|o)\/Account\//i.test(page.url());
}
/**
 * Logs into the configured LMA org, searches for the subscriber org,
 * clicks the subscriber Login link, and navigates directly to
 * Equifax Consumer Reports.
 *
 * Required .env values for LMA mode:
 * - LMA_URL
 * - LMA_USERNAME
 * - LMA_PASSWORD
 * - SUBSCRIBER_ORG_ID
 * - SUBSCRIBER_ORG_NAME
 */

/**
 * Logs directly into a Salesforce org using SF_BASE_URL,
 * SF_USERNAME, and SF_PASSWORD from .env.
 *
 * This flow skips the LMA subscriber login completely.
 */
/**
 * Logs directly into Salesforce using SF_BASE_URL,
 * SF_USERNAME, and SF_PASSWORD from .env.
 *
 * Supports both:
 * - Username and password displayed together.
 * - Username first, followed by the password screen.
 */
/**
 * Logs directly into Salesforce using SF_BASE_URL,
 * SF_USERNAME, and SF_PASSWORD from .env.
 *
 * Supports:
 * - Username and password displayed together.
 * - Username first, followed by the password screen.
 * - Manual verification-code entry when Salesforce requires it.
 */
/**
 * Logs directly into Salesforce using SF_BASE_URL,
 * SF_USERNAME, and SF_PASSWORD from .env.
 *
 * Supports:
 * - Username and password displayed together.
 * - Username first, followed by the password screen.
 * - Manual verification-code entry when Salesforce requires it.
 */
/**
 * Logs directly into Salesforce using SF_BASE_URL,
 * SF_USERNAME, and SF_PASSWORD from .env.
 *
 * Supports:
 * - Username and password displayed together.
 * - Username first, followed by the password screen.
 * - Manual verification-code entry.
 */
// Logs directly into Salesforce using SF_BASE_URL,
// SF_USERNAME, and SF_PASSWORD from .env.
//
// Supports:
// - Username and password displayed together.
// - Username first, followed by the password screen.
// - Manual verification-code entry.

async function loginDirectlyToSalesforce(
    page: Page
): Promise<Page> {
    console.log('Using direct Salesforce login...');

    const configuredOrgUrl = env.sfBaseUrl!;

    await page.goto(
        configuredOrgUrl,
        {
            waitUntil: 'domcontentloaded',
        }
    );

    const usernameField =
        page.locator('#username');

    const passwordField =
        page.locator('#password');

    const loginButton =
        page.locator('#Login');

    if (await isVisible(usernameField)) {
        await usernameField.fill(
            env.sfUsername!
        );

        // Some Salesforce login pages show the
        // password only after username is submitted.
        if (!(await isVisible(passwordField))) {
            console.log(
                'Submitting username and waiting for password field...'
            );

            await loginButton.click();

            await expect(
                passwordField
            ).toBeVisible({
                timeout: 60000,
            });
        }

        await passwordField.fill(
            env.sfPassword!
        );

        await loginButton.click();

        console.log(
            'Direct Salesforce login submitted.'
        );
    } else {
        console.log(
            'Existing Salesforce session detected.'
        );
    }

    // Check whether Salesforce requests
    // identity verification.
    const verificationInput = page.locator(
        '#emc, ' +
        '#smc, ' +
        'input[name="emc"], ' +
        'input[name="verificationCode"], ' +
        'input[id*="verification"], ' +
        'input[autocomplete="one-time-code"]'
    ).first();

    const verificationRequired =
        await verificationInput
            .waitFor({
                state: 'visible',
                timeout: 15000,
            })
            .then(() => true)
            .catch(() => false);

    if (verificationRequired) {
        console.log(
            'Salesforce identity verification is required.'
        );

        console.log(
            'Enter the verification code manually and submit it.'
        );

        console.log(
            'Waiting for Salesforce to complete authentication...'
        );
    }

    // Do not navigate anywhere while Salesforce
    // login or verification is still in progress.
    //
    // Continue only when Salesforce reaches
    // an authenticated org page.
    await page.waitForURL(
        url => {
            const currentUrl =
                url.toString().toLowerCase();

            const isSalesforceOrg =
                currentUrl.includes(
                    '.salesforce.com/'
                ) ||
                currentUrl.includes(
                    '.force.com/'
                );

            const isAuthenticationPage =
                currentUrl.includes(
                    'login.salesforce.com'
                ) ||
                currentUrl.includes(
                    'verify'
                ) ||
                currentUrl.includes(
                    'identity'
                ) ||
                currentUrl.includes(
                    'challenge'
                );

            return (
                isSalesforceOrg &&
                !isAuthenticationPage
            );
        },
        {
            timeout: 300000,
        }
    );

    console.log(
        'Direct Salesforce authentication completed.'
    );

    // Salesforce may continue through internal redirects
    // after verification. Wait until those redirects finish.
    await page.waitForLoadState(
        'domcontentloaded'
    );

    await page.waitForTimeout(3000);

    // Wait until Salesforce is no longer using the
    // temporary contentDoor authentication redirect.
    await page.waitForURL(
        url => {
            const currentUrl =
                url.toString().toLowerCase();

            return (
                !currentUrl.includes('contentdoor') &&
                !currentUrl.includes('login.salesforce.com')
            );
        },
        {
            timeout: 120000,
        }
    );

    console.log(
        'Salesforce post-login redirects completed.'
    );

    // Use the final authenticated org origin.
    const salesforceOrigin =
        new URL(page.url()).origin;

    console.log(
        `Salesforce org detected: ${salesforceOrigin}`
    );

    const consumerReportsUrl =
        `${salesforceOrigin}/lightning/o/` +
        `forseva1__EquifaxConsumer__c/` +
        `list?filterName=__Recent`;

    await page.goto(
        consumerReportsUrl,
        {
            waitUntil: 'domcontentloaded',
        }
    );
    await page.waitForURL(
        '**/lightning/o/forseva1__EquifaxConsumer__c/**',
        {
            timeout: 120000,
        }
    );

    await page.bringToFront();

    console.log(
        'Equifax Consumer Reports page loaded:',
        page.url()
    );

    return page;
}

async function loginToSalesforce(page: Page): Promise<Page> {
    console.log('Navigating to LMA...');

    await page.goto(env.baseUrl!, { waitUntil: 'domcontentloaded' });

    // Already inside the subscriber org - skip the complete LMA flow.
    if (await isSubscriberAccountPage(page)) {
        console.log('Subscriber org session already available.');
        return page;
    }

    const usernameField = page.locator('#username');

    if (await isVisible(usernameField)) {
        await test.step('Enter LMA credentials', async () => {
            await usernameField.fill(env.username!);
            await page.locator('#Login').click();

            const passwordField = page.locator('#password');
            await expect(passwordField).toBeVisible({ timeout: 60000 });
            await passwordField.fill(env.password!);
            await page.locator('#Login').click();
        }, { box: true });

        console.log('LMA login submitted.');
    } else {
        console.log('Existing LMA session detected.');
    }

    // LMA opens in Salesforce Classic - do not wait for a /lightning/ URL here.
    const subscribersTab = page.getByRole('link', { name: /^Subscribers$/i });
    await expect(subscribersTab).toBeVisible({ timeout: 120000 });
    await subscribersTab.click();
    console.log('Subscribers tab opened.');

    await expect(
        page.getByText('Subscriber Organizations', { exact: true })
    ).toBeVisible({ timeout: 30000 });

    // First textbox = global search; last = Subscriber list search.
    const textboxes = page.getByRole('textbox');
    await expect
        .poll(() => textboxes.count(), { timeout: 30000, intervals: [250, 500] })
        .toBeGreaterThanOrEqual(2);

    const subscriberSearch = textboxes.last();
    await expect(subscriberSearch).toBeVisible({ timeout: 30000 });
    await subscriberSearch.fill(env.subscriberOrgId!);
    await subscriberSearch.press('Enter');
    console.log(`Subscriber Org searched: ${env.subscriberOrgId}`);

    // Subscriber organization name is supplied through SUBSCRIBER_ORG_NAME.
    const subscriberOrgLink = page.getByRole('link', {
        name: env.subscriberOrgName!,
        exact: true,
    });
    await expect(subscriberOrgLink).toBeVisible({ timeout: 30000 });

    const [overviewPage] = await Promise.all([
        page.context().waitForEvent('page'),
        subscriberOrgLink.click(),
    ]);
    await overviewPage.waitForLoadState('domcontentloaded');
    console.log('Overview URL:', overviewPage.url());

    await expect(overviewPage.locator('body')).toContainText(
        'Login Access Granted',
        { timeout: 30000 }
    );
    console.log(
        `${env.subscriberOrgName} Subscriber Overview opened.`
    );

    // Pick the Login link for the intended subscriber username (if provided).
    const subscriberLoginUsername = process.env.SUBSCRIBER_LOGIN_USERNAME;
    let loginLink: Locator;

    if (subscriberLoginUsername) {
        const loginRow = overviewPage
            .getByRole('row')
            .filter({ hasText: subscriberLoginUsername });

        await expect(loginRow).toBeVisible({ timeout: 30000 });
        loginLink = loginRow.getByRole('link', { name: /^Login$/i });
    } else {
        const loginLinks = overviewPage.getByRole('link', { name: /^Login$/i });
        const count = await loginLinks.count();
        console.log(`Subscriber Login links found: ${count}`);

        if (count === 0) {
            throw new Error('No subscriber Login link was found.');
        }
        loginLink = loginLinks.first();
    }

    await expect(loginLink).toBeVisible({ timeout: 30000 });

    // Subscriber Login may open a new tab or reuse the current tab.
    const context = overviewPage.context();
    const pagesBeforeLogin = context.pages();
    const overviewUrlBeforeLogin = overviewPage.url();

    console.log('Clicking Subscriber Login...');

    const loginOutcome = waitForOutcome({
        newPage: () =>
            context.waitForEvent('page', {
                timeout: 30000,
            }),

        sameTab: () =>
            overviewPage.waitForURL(
                url => url.toString() !== overviewUrlBeforeLogin,
                {
                    timeout: 30000,
                }
            ),
    });

    await loginLink.click();

    const outcome = await loginOutcome;

    console.log(
        `Subscriber login outcome: ${outcome}`
    );

    let subscriberPage: Page;

    const newPages = context
        .pages()
        .filter(
            candidate =>
                !pagesBeforeLogin.includes(candidate)
        );

    if (newPages.length > 0) {
        subscriberPage =
            newPages[newPages.length - 1];

        console.log(
            'Subscriber opened in new tab.'
        );
    } else {
        subscriberPage = overviewPage;

        console.log(
            'Subscriber reused existing tab.'
        );
    }

    await subscriberPage.waitForLoadState(
        'domcontentloaded'
    );

    await subscriberPage.bringToFront();

    console.log(
        'Subscriber URL after Login:',
        subscriberPage.url()
    );

    // Get the actual subscriber org.
    const subscriberOrigin =
        new URL(subscriberPage.url()).origin;

    console.log(
        `Subscriber org detected: ${subscriberOrigin}`
    );

    // Go DIRECTLY to Equifax Consumer Reports.
    // No Accounts navigation.
    await subscriberPage.goto(
        `${subscriberOrigin}/lightning/o/forseva1__EquifaxConsumer__c/list?filterName=__Recent`,
        {
            waitUntil: 'domcontentloaded',
        }
    );

    await subscriberPage.waitForURL(
        '**/lightning/o/forseva1__EquifaxConsumer__c/**',
        {
            timeout: 120000,
        }
    );

    await subscriberPage.bringToFront();

    console.log(
        'Equifax Consumer Reports page loaded:',
        subscriberPage.url()
    );

    return subscriberPage;
}

/* ------------------------------------------------------------------ */
/* Consumer Report List View                                          */
/* ------------------------------------------------------------------ */

// Selects the list view configured by LIST_VIEW_NAME in .env.
// Recommended columns:
// - Equifax Consumer Report ID
// - Account
// - Created Date
//
// Created Date should be sorted newest to oldest.

async function selectTestListView(
    page: Page
): Promise<void> {
    console.log(
        `Selecting ${env.listViewName} list view...`
    );
    const listViewButton = page.getByRole('button', {
        name: 'Select a List View: Equifax Consumer Reports',
        exact: true,
    });

    await expect(listViewButton).toBeVisible({
        timeout: 60000,
    });

    await listViewButton.click();

    console.log('List view dropdown opened.');

    const listViewOption = page
        .getByText(env.listViewName!, {
            exact: true,
        })
        .last();

    await expect(listViewOption).toBeVisible({
        timeout: 10000,
    });

    await listViewOption.click();

    console.log(
        `${env.listViewName} list view selected.`
    );
}
/* ------------------------------------------------------------------ */
/* Report Data Models                                                 */
/* ------------------------------------------------------------------ */

// Stores the Consumer Report information collected from Salesforce.
// accountName may initially be "UnknownAccount" when Account is not
// available in the selected list view.
type ConsumerReport = {
    name: string;
    accountName: string;
    url: string;
    createdDate: string;
};

// Stores the XML processing result for one Consumer Report.
// Downloaded = XML file was successfully saved.
// Error = XML was unavailable or another handled error occurred.
type XmlResult = {
    reportName: string;
    createdDate: string;
    status: 'Downloaded' | 'Error';
    fileName: string;
    errorMessage: string;
    screenshotPath: string;
};

type XmlClickResult = {
    download: import('@playwright/test').Download | null;
    errorText: string;
};
/* ------------------------------------------------------------------ */
/* Date Range and File Utilities                                      */
/* ------------------------------------------------------------------ */

// Calculates the cutoff date based on MONTH_RANGE from .env.
function getCutoffDate(): Date {
    const date = new Date();
    date.setMonth(date.getMonth() - env.monthRange);
    date.setHours(0, 0, 0, 0);
    return date;
}

// Removes/replaces characters that cannot be used in Windows filenames.

function safeFileName(value: string): string {
    return value.replace(/[<>:"/\\|?*]/g, '_');
}

// Converts the Salesforce Created Date text into a JavaScript Date
// so it can be compared with the configured cutoff date.
function parseSalesforceDate(
    value: string
): Date | null {
    const match = value.match(
        /(\d{1,2})\/(\d{1,2})\/(\d{4})(?:,\s*(\d{1,2}):(\d{2})\s*(AM|PM))?/i
    );

    if (!match) {
        return null;
    }

    const month = Number(match[1]) - 1;
    const day = Number(match[2]);
    const year = Number(match[3]);

    let hour = Number(match[4] || 0);
    const minute = Number(match[5] || 0);
    const amPm = match[6]?.toUpperCase();

    if (amPm === 'PM' && hour !== 12) {
        hour += 12;
    }

    if (amPm === 'AM' && hour === 12) {
        hour = 0;
    }

    return new Date(
        year,
        month,
        day,
        hour,
        minute
    );
}
/* ------------------------------------------------------------------ */
/* Consumer Report Collection                                        */
/* ------------------------------------------------------------------ */

// Collects Consumer Reports within the configured MONTH_RANGE.
//
// The selected list view must be sorted by Created Date,
// newest to oldest.
//
// The automation keeps scrolling and collecting records until
// it reaches a report older than the configured cutoff date.
async function collectReportsWithinRange(
    page: Page
): Promise<ConsumerReport[]> {
    const cutoffDate = getCutoffDate();

    console.log(
        `Collecting reports created on or after ${cutoffDate.toLocaleDateString()}`
    );

    const collected = new Map<string, ConsumerReport>();

    const scrollContainer = page
        .locator(
            '.slds-scrollable_y, ' +
            '.uiScroller.scroller-wrapper, ' +
            'lightning-datatable .slds-scrollable_y'
        )
        .filter({
            has: page.getByRole('link').filter({
                hasText: /^EfxConsumer-\d+$/i,
            }),
        })
        .first();

    let unchangedRounds = 0;
    let previousCount = 0;
    for (let round = 1; round <= 100; round++) {
        const reportLinks = page
            .getByRole('link')
            .filter({
                hasText: /^EfxConsumer-\d+$/i,
            });

        await expect
            .poll(() => reportLinks.count(), {
                timeout: 60000,
                intervals: [500, 1000],
            })
            .toBeGreaterThan(0);

        const visibleLinkCount = await reportLinks.count();

        console.log(
            `Collection round ${round}: rendered links=${visibleLinkCount}`
        );

        for (let index = 0; index < visibleLinkCount; index++) {
            const reportLink = reportLinks.nth(index);

            const reportName = (
                await reportLink.innerText().catch(() => '')
            ).trim();

            const href = await reportLink.getAttribute('href');

            if (!reportName || !href || collected.has(reportName)) {
                continue;
            }

            const row = reportLink.locator('xpath=ancestor::tr[1]');

            const createdDateCell = row
                .locator(
                    'td[data-label="Created Date"], ' +
                    'th[data-label="Created Date"]'
                )
                .first();

            let createdDateText = '';

            if (await isVisible(createdDateCell)) {
                createdDateText = (
                    await createdDateCell.innerText()
                )
                    .replace(/\s+/g, ' ')
                    .trim();
            } else {
                const cells = row.locator('td, th');
                const cellCount = await cells.count();

                for (
                    let cellIndex = 0;
                    cellIndex < cellCount;
                    cellIndex++
                ) {
                    const cellText = (
                        await cells
                            .nth(cellIndex)
                            .innerText()
                            .catch(() => '')
                    )
                        .replace(/\s+/g, ' ')
                        .trim();

                    const dateMatch = cellText.match(
                        /\d{1,2}\/\d{1,2}\/\d{4},\s*\d{1,2}:\d{2}\s*(?:AM|PM)/i
                    );

                    if (dateMatch) {
                        createdDateText = dateMatch[0];
                        break;
                    }
                }
            }

            if (!createdDateText) {
                console.log(
                    `Created Date unavailable for ${reportName}.`
                );
                continue;
            }


            const createdDate = parseSalesforceDate(
                createdDateText
            );

            if (!createdDate) {
                console.log(
                    `Unable to parse date for ${reportName}: ${createdDateText}`
                );
                continue;
            }

            console.log(
                `${reportName} | Created Date=${createdDateText}`
            );

            if (
                createdDate.getTime() <
                cutoffDate.getTime()
            ) {
                console.log(
                    `Reached report older than ${env.monthRange} month(s): ${reportName}`
                );

                console.log(
                    'Stopping collection because list is sorted newest to oldest.'
                );

                return Array.from(collected.values());
            }
            const accountCell = row
                .locator(
                    'td[data-label="Account"], ' +
                    'th[data-label="Account"]'
                )
                .first();

            let accountName = '';

            if (await isVisible(accountCell)) {
                accountName = (
                    await accountCell.innerText()
                )
                    .replace(/\s+/g, ' ')
                    .trim();
            }

            if (!accountName) {
                const accountLink = row
                    .locator('a[href*="/lightning/r/Account/"]')
                    .first();

                if (await isVisible(accountLink)) {
                    accountName = (
                        await accountLink.innerText()
                    )
                        .replace(/\s+/g, ' ')
                        .trim();
                }
            }

            if (!accountName) {
                accountName = 'UnknownAccount';
            }

            console.log(
                `${reportName} | Account=${accountName} | Created Date=${createdDateText}`
            );

            collected.set(reportName, {
                name: reportName,
                accountName,
                url: new URL(
                    href,
                    page.url()
                ).toString(),
                createdDate: createdDateText,
            });

            console.log(
                `Added report: ${reportName}`
            );
        }

        if (collected.size === previousCount) {
            unchangedRounds++;
        } else {
            unchangedRounds = 0;
            previousCount = collected.size;
        }

        console.log(
            `Reports collected=${collected.size}, unchangedRounds=${unchangedRounds}`
        );

        if (unchangedRounds >= 5) {
            break;
        }
        const countBeforeScroll =
            await reportLinks.count();

        if (await isVisible(scrollContainer)) {
            await scrollContainer.evaluate(element => {
                element.scrollTop = element.scrollHeight;

                element.dispatchEvent(
                    new Event('scroll', {
                        bubbles: true,
                    })
                );
            });
        } else {
            await page.mouse.wheel(0, 8000);
        }

        await expect
            .poll(
                () => reportLinks.count(),
                {
                    timeout: 3000,
                    intervals: [100, 200, 300],
                }
            )
            .toBeGreaterThanOrEqual(countBeforeScroll);
    }

    const reports = Array.from(collected.values());

    console.log(
        `Total unique reports from last ${env.monthRange} month(s): ${reports.length}`
    );

    return reports;
}



/* ------------------------------------------------------------------ */
/* XML Download and Error Detection                                   */
/* ------------------------------------------------------------------ */

// Clicks the XML button and waits for either:
// 1. An XML download, or
// 2. The known XML-unavailable error message.

async function clickXmlAndWaitForDownload(
    page: Page,
    reportName: string
): Promise<XmlClickResult> {
    console.log(`Waiting for report page: ${reportName}`);

    const reportHeading = page.getByRole('heading', {
        name: reportName,
        exact: true,
    });

    await expect(reportHeading).toBeVisible({
        timeout: 60000,
    });

    const xmlButton = page.getByRole('button', {
        name: /^XML$/i,
        exact: true,
    });

    await expect(xmlButton).toBeVisible({
        timeout: 30000,
    });

    await expect(xmlButton).toBeEnabled({
        timeout: 30000,
    });

    await xmlButton.scrollIntoViewIfNeeded();

    console.log(`Clicking XML for ${reportName}`);

    const downloadPromise = page
        .waitForEvent('download', {
            timeout: 10000,
        })
        .then(download => ({
            type: 'download' as const,
            download,
        }));

    const errorPromise = page.waitForFunction(
        () =>
            document.body?.innerText
                .toLowerCase()
                .includes('cannot view report because xml'),
        undefined,
        {
            timeout: 10000,
            polling: 50,
        }
    ).then(() => ({
        type: 'error' as const,
        errorText: 'Cannot view report because XML',
    }));

    await xmlButton.click();

    console.log(`XML clicked for ${reportName}`);

    try {
        const outcome = await Promise.race([
            downloadPromise,
            errorPromise,
        ]);

        if (outcome.type === 'download') {
            console.log(
                `XML download detected for ${reportName}`
            );

            return {
                download: outcome.download,
                errorText: '',
            };
        }

        console.log(
            `XML error detected immediately for ${reportName}`
        );

        return {
            download: null,
            errorText: outcome.errorText,
        };

    } catch {
        console.log(
            `No XML download or error detected for ${reportName}`
        );

        return {
            download: null,
            errorText:
                'No XML response was detected within 10 seconds.',
        };
    }
}

// Fallback Account lookup.
//
// Used only when the Account name was not available in the list view.
// After the Consumer Report is opened, the automation reads
// the Account field displayed in the report's Details section.
async function getAccountNameFromReport(
    page: Page
): Promise<string> {

    // Open the Details section when it is available.
    const detailsTab = page.getByRole('tab', {
        name: 'Details',
        exact: true,
    });

    if (await detailsTab.isVisible().catch(() => false)) {
        const selected =
            await detailsTab.getAttribute('aria-selected');

        if (selected !== 'true') {
            await detailsTab.click();
        }
    }

    const accountLabel = page.getByText('Account', {
        exact: true,
    }).first();

    const accountRendered = await accountLabel
        .waitFor({
            state: 'visible',
            timeout: 10000,
        })
        .then(() => true)
        .catch(() => false);

    if (!accountRendered) {
        console.log(
            'Account label was not found under Details.'
        );

        return 'UnknownAccount';
    }

    // Move up to the Salesforce field container,
    // then read the linked Account value.
    const accountField = accountLabel.locator(
        'xpath=ancestor::*[.//a][1]'
    );

    const accountLink = accountField.locator('a').first();

    const accountName = (
        await accountLink
            .innerText({ timeout: 5000 })
            .catch(() => '')
    )
        .replace(/\s+/g, ' ')
        .trim();

    if (accountName) {
        console.log(
            `Account found inside report: ${accountName}`
        );

        return accountName;
    }

    console.log(
        'Account link was not found under the Account field.'
    );

    return 'UnknownAccount';
}

// Processes one Consumer Report.
//
// The automation:
// - Opens the Consumer Report.
// - Resolves the Account name if necessary.
// - Clicks XML.
// - Saves the XML when available.
// - Captures a screenshot when XML is unavailable.
async function downloadXmlForReport(
    page: Page,
    report: ConsumerReport,
    downloadFolder: string,
    screenshotFolder: string
): Promise<XmlResult> {
    console.log(
        `Opening Consumer Report: ${report.name}`
    );

    await page.goto(report.url, {
        waitUntil: 'domcontentloaded',
    });

    await page.waitForLoadState(
        'domcontentloaded'
    );

    console.log(
        `Consumer Report opened: ${report.name}`
    );

    // Only use report page as fallback when Account
    // wasn't available in the list view.
    if (report.accountName === 'UnknownAccount') {
        report.accountName =
            await getAccountNameFromReport(page);

        console.log(
            `Account from report: ${report.accountName}`
        );
    }

    const xmlResult =
        await clickXmlAndWaitForDownload(
            page,
            report.name
        );

    const download = xmlResult.download;
    const xmlErrorText = xmlResult.errorText;
    if (download) {
        const suggestedFileName =
            download.suggestedFilename();

        const suggestedExtension =
            path.extname(suggestedFileName) || '.xml';

        const finalFileName =
            `${safeFileName(report.accountName)}_` +
            `${safeFileName(report.name)}` +
            `${suggestedExtension}`;

        const downloadPath = path.join(
            downloadFolder,
            finalFileName
        );

        await download.saveAs(
            downloadPath
        );

        console.log(
            `XML downloaded successfully: ${finalFileName}`
        );

        return {
            reportName: report.name,
            createdDate: report.createdDate,
            status: 'Downloaded',
            fileName: finalFileName,
            errorMessage: '',
            screenshotPath: '',
        };
    }

    console.log(
        `No XML download detected for ${report.name}.`
    );

    let errorText = xmlErrorText;

    if (!errorText) {
        errorText =
            'XML download was not generated.';
    }
    console.log(
        `XML error for ${report.name}: ${errorText}`
    );

    const screenshotPath = path.join(
        screenshotFolder,
        `${safeFileName(report.accountName)}_` +
        `${safeFileName(report.name)}-XML-error.png`
    );



    await page.screenshot({
        path: screenshotPath,
        fullPage: false,
        animations: 'disabled',
    });

    console.log(
        `XML error screenshot captured for ${report.name}`
    );
    return {
        reportName: report.name,
        createdDate: report.createdDate,
        status: 'Error',
        fileName: '',
        errorMessage:
            errorText.slice(0, 1500),
        screenshotPath,
    };
}

/* ------------------------------------------------------------------ */
/* Checkpoint and Resume                                              */
/* ------------------------------------------------------------------ */

// progress.json stores report IDs that have already been completed.
// When the automation is restarted, completed reports are skipped.
function loadProgress(
    progressFile: string
): Set<string> {
    if (!fs.existsSync(progressFile)) {
        console.log('No previous progress found. Starting fresh.');
        return new Set<string>();
    }

    try {
        const savedReports = JSON.parse(
            fs.readFileSync(progressFile, 'utf8')
        ) as string[];

        console.log(
            `Previous progress loaded: ${savedReports.length} report(s) completed.`
        );

        return new Set<string>(savedReports);
    } catch {
        console.log(
            'Progress file could not be read. Starting fresh.'
        );

        return new Set<string>();
    }
}

function saveProgress(
    progressFile: string,
    processedReports: Set<string>
): void {
    fs.writeFileSync(
        progressFile,
        JSON.stringify(
            Array.from(processedReports),
            null,
            2
        ),
        'utf8'
    );
}
// reports.json stores the reports collected for the current run.
//
// If the automation is interrupted, the saved report list is reused
// so Salesforce does not need to be scanned again.
function saveReportList(
    reportsFile: string,
    reports: ConsumerReport[]
): void {
    fs.writeFileSync(
        reportsFile,
        JSON.stringify(reports, null, 2),
        'utf8'
    );
}

function loadReportList(
    reportsFile: string
): ConsumerReport[] {
    if (!fs.existsSync(reportsFile)) {
        return [];
    }

    try {
        return JSON.parse(
            fs.readFileSync(reportsFile, 'utf8')
        ) as ConsumerReport[];
    } catch {
        console.log(
            'Saved reports.json could not be read.'
        );

        return [];
    }
}
/* ------------------------------------------------------------------ */
/* Main Consumer XML Download Test                                    */
/* ------------------------------------------------------------------ */

// Main workflow:
// 1. Login to Salesforce.
// 2. Open Equifax Consumer Reports.
// 3. Select the list view configured in .env.
// 4. Collect reports within MONTH_RANGE or load reports.json.
// 5. Resume from progress.json when available.
// 6. Download XML files or capture XML-error screenshots.
// 7. Rename Current_Run after all reports are completed.
test(
    `Download last ${env.monthRange} ${env.monthRange === 1 ? 'month' : 'months'
    } of Consumer Report XML files`,
    async ({ page: initialPage }) => {
        test.setTimeout(1800000);

        // STEP 1 - Login using the method configured in LOGIN_MODE.
        const page =
            env.loginMode.toUpperCase() === 'DIRECT'
                ? await loginDirectlyToSalesforce(initialPage)
                : await loginToSalesforce(initialPage);

        // STEP 2 - Confirm Equifax Consumer Reports is open

        console.log(
            'Equifax Consumer Reports opened.'
        );

        // STEP 3 - Select the configured list view

        await selectTestListView(page);

        // STEP 4 - Prepare output folders
        // DOWNLOAD_PATH is optional.
        //
        // If DOWNLOAD_PATH is blank in .env, the automation uses the
        // current Windows user's Downloads folder.
        const baseDownloadPath =
            env.downloadPath ||
            path.join(
                os.homedir(),
                'Downloads'
            );

        const runFolder = path.join(
            baseDownloadPath,
            'Current_Run'
        );

        const downloadFolder = path.join(
            runFolder,
            'XML'
        );

        const screenshotFolder = path.join(
            runFolder,
            'Errors'
        );

        const progressFile = path.join(
            runFolder,
            'progress.json'
        );
        const reportsFile = path.join(
            runFolder,
            'reports.json'
        );

        fs.mkdirSync(downloadFolder, {
            recursive: true,
        });

        fs.mkdirSync(screenshotFolder, {
            recursive: true,
        });

        console.log(
            `Current run folder: ${runFolder}`
        );
        // STEP 5 - Collect or load the report list

        // First collect and count all qualifying reports.
        let reports: ConsumerReport[];

        if (fs.existsSync(reportsFile)) {
            console.log(
                'RESUME: Existing reports.json found.'
            );

            reports =
                loadReportList(reportsFile);

            console.log(
                `RESUME: Loaded ${reports.length} saved reports. ` +
                `Salesforce report collection skipped.`
            );
        } else {
            console.log(
                'NEW RUN: Collecting reports from Salesforce.'
            );

            reports =
                await collectReportsWithinRange(page);

            saveReportList(
                reportsFile,
                reports
            );

            console.log(
                `NEW RUN: Saved ${reports.length} reports to reports.json`
            );
        }

        console.log(
            `Total reports available for processing: ${reports.length}`
        );

        const rangeLabel =
            `${env.monthRange} ` +
            `${env.monthRange === 1 ? 'month' : 'months'}`;

        expect(
            reports.length,
            `No Consumer Reports from the last ${rangeLabel} were found.`
        ).toBeGreaterThan(0);

        const results: XmlResult[] = [];

        const processedReports =
            loadProgress(progressFile);

        console.log(
            `Reports already completed: ${processedReports.size}`
        );
        // STEP 6 - Process reports and save checkpoints
        for (
            let index = 0;
            index < reports.length;
            index++
        ) {
            const report = reports[index];

            if (processedReports.has(report.name)) {
                console.log(
                    `Already completed. Skipping: ` +
                    `${report.accountName} | ${report.name}`
                );

                continue;
            }

            console.log(
                `Processing ${index + 1}/${reports.length}: ` +
                `${report.accountName} | ${report.name}`
            );

            let reportFinished = false;

            try {
                const result =
                    await downloadXmlForReport(
                        page,
                        report,
                        downloadFolder,
                        screenshotFolder
                    );

                results.push(result);

                // downloadXmlForReport completed normally.
                // This includes a valid download OR handled XML error.
                reportFinished = true;

            } catch (error) {
                const errorMessage =
                    error instanceof Error
                        ? error.message
                        : String(error);

                console.log(
                    `Automation failure for ${report.name}: ${errorMessage}`
                );

                const screenshotPath = path.join(
                    screenshotFolder,
                    `${safeFileName(report.accountName)}_` +
                    `${safeFileName(report.name)}-unexpected-error.png`
                );

                await page
                    .screenshot({
                        path: screenshotPath,
                        fullPage: true,
                    })
                    .catch(() => undefined);

                results.push({
                    reportName: report.name,
                    createdDate: report.createdDate,
                    status: 'Error',
                    fileName: '',
                    errorMessage,
                    screenshotPath,
                });

                // IMPORTANT:
                // Do NOT add this report to progress.json.
                // It will be retried when the test resumes.
                console.log(
                    `${report.name} was NOT checkpointed and will be retried.`
                );
            }

            if (reportFinished) {
                processedReports.add(report.name);

                saveProgress(
                    progressFile,
                    processedReports
                );

                console.log(
                    `Checkpoint saved: ` +
                    `${processedReports.size}/${reports.length}`
                );
            }
        }
        const failedResults = results.filter(
            result => result.status === 'Error'
        );

        console.log(
            `Consumer XML processing completed. ` +
            `Available=${reports.length}, Processed=${results.length}`
        );

        console.log(
            `Consumer XML processing finished. ` +
            `Processed this execution=${results.length}, ` +
            `Total completed=${processedReports.size}, ` +
            `Total reports=${reports.length}, ` +
            `Remaining=${reports.length - processedReports.size}`
        );
        const remaining =
            reports.length - processedReports.size;
        // All reports are completed.
        //
        // Rename Current_Run to Completed_<date_time>.
        //
        // IMPORTANT:
        // Do not keep Current_Run, the XML folder, the Errors folder,
        // or files inside them open at this point.
        // Windows may lock the folder and prevent the rename.
        if (remaining === 0) {
            const now = new Date();

            const timestamp =
                `${now.getFullYear()}-` +
                `${String(now.getMonth() + 1).padStart(2, '0')}-` +
                `${String(now.getDate()).padStart(2, '0')}_` +
                `${String(now.getHours()).padStart(2, '0')}-` +
                `${String(now.getMinutes()).padStart(2, '0')}-` +
                `${String(now.getSeconds()).padStart(2, '0')}`;

            const completedFolder = path.join(
                baseDownloadPath,
                `Completed_${timestamp}`
            );

            for (let attempt = 1; attempt <= 3; attempt++) {
                try {
                    fs.renameSync(
                        runFolder,
                        completedFolder
                    );

                    console.log(
                        `Run completed. Folder renamed to: ${completedFolder}`
                    );

                    break;
                } catch (error) {
                    console.log(
                        `Rename attempt ${attempt}/3 failed.`
                    );

                    if (attempt < 3) {
                        await page.waitForTimeout(500);
                    } else {
                        const renameError =
                            error instanceof Error
                                ? error.message
                                : String(error);

                        throw new Error(
                            `All Consumer XML reports were processed successfully, ` +
                            `but Current_Run could not be renamed to the completed folder. ` +
                            `Reason: ${renameError}`
                        );
                    }
                }
            }
        } else {
            console.log(
                `Run incomplete. Keeping Current_Run for resume. Remaining=${remaining}`
            );
        }
        if (remaining > 0) {
            throw new Error(
                `Consumer XML test incomplete. ` +
                `Remaining=${remaining}, ` +
                `Total=${reports.length}`
            );
        }

        console.log(
            `Consumer XML run completed. ` +
            `XML downloaded/errors processed=${results.length}, ` +
            `XML errors=${failedResults.length}, ` +
            `Total=${reports.length}`
        );
    }
);